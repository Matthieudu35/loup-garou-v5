import { writable, derived, get } from 'svelte/store';
import { browser } from '$app/environment';
import { page } from '$app/stores';
import type { TimerState } from './timerStore';
import type { User } from './types';
import type { Association, Memo } from '$lib/types';
import type { EliminationSource, EliminationReason } from './eliminationStore';
import { getVoteResult, resetDayVotes, startSecondRound, resetAll, isSecondRound } from './dayVoteStore';
import { getUserByLogin, setUsers } from './usersStore';
import { eliminationStore } from './eliminationStore';
import { timer } from './timerStore';
import { enfantSauvageStates } from './enfantSauvageStore';
import { chienLoupStates } from './chienLoupStore';
import { allies } from './alliesStore';
import { memos } from './memosStore';

const apiURL = 'https://proactive-balance-production.up.railway.app';

// Types et interfaces
interface GameState {
    phase: 'jour' | 'nuit' | null;
    cycleCount: number;
    showMayorElection: string | null;
    mayor: string | null;
    gameStarted: boolean;
    showSecondRoundAnnouncement: boolean;
    showVoteCountdown: boolean;
    timer: {
        timer: number;
        initialTimer: number;
        running: boolean;
        subTimers: Record<string, number>;
    };
    rolesAssigned: boolean;
    enfantSauvageStates: Record<string, { login: string; masterLogin: string | null; hasSwitched: boolean; }>;
    chienLoupStates: Record<string, { login: string; camp: 'loups' | 'village' | null; hasChosen: boolean; }>;
    eliminations: Array<{ playerLogin: string; reason: string; source: string; }>;
    users: {
        login: string;
        password: string;
        firstName: string;
        lastName?: string;
        photoUrl?: string;
        isAlive: boolean;
        isAdmin: boolean;
        isCurrentUser?: boolean;
        isMayor?: boolean;
        role?: string;
        photoPlaceholder?: string;
    }[];
    allies: Association[];
    memos: Memo[];
    loupVotes: Record<string, string>;
    loupVictim: string | null;
    dayVotes: Record<string, string>;
    isSecondRound: boolean;
    secondRoundCandidates: string[];
    subTimers: {
        id: string;
        label: string;
        percent: number;
        startTime: number;
        endTime: number;
        duration: number;
        isActive: boolean;
        color: string;
        roles: string[];
        order?: number;
    }[];
    selectedPlayers: string[];
}

// État initial du jeu
const initialState: GameState = {
    phase: null,
    cycleCount: 0,
    showMayorElection: null,
    mayor: null,
    gameStarted: false,
    showSecondRoundAnnouncement: false,
    showVoteCountdown: false,
    timer: {
        timer: 3600,
        initialTimer: 3600,
        running: false,
        subTimers: {}
    },
    rolesAssigned: false,
    enfantSauvageStates: {},
    chienLoupStates: {},
    eliminations: [],
    users: [],
    allies: [],
    memos: [],
    loupVotes: {},
    loupVictim: null,
    dayVotes: {},
    isSecondRound: false,
    secondRoundCandidates: [],
    subTimers: [],
    selectedPlayers: [],
};

// Création du store avec l'état initial
export const gameState = writable<GameState>(initialState);

// Callbacks pour la synchronisation
let onTimerChange: ((timerState: TimerState) => void) | null = null;
let onRolesAssignedChange: ((assigned: boolean) => void) | null = null;
let onUsersChange: ((users: User[]) => void) | null = null;
let onSelectedPlayersChange: ((players: string[]) => void) | null = null;
let onDayVotesChange: ((votes: Record<string, string>) => void) | null = null;
let onSecondRoundChange: ((isSecondRound: boolean, candidates: string[]) => void) | null = null;
let onCurrentUserChange: ((login: string | null) => void) | null = null;

// Fonction pour initialiser les subscriptions côté navigateur
function initializeBrowserSubscriptions() {
    if (!browser) return;
    
    // Restaurer l'état du jeu depuis le backend
    fetchGameState();
    
    // Mise à jour régulière du gameState depuis le backend
    setInterval(fetchGameState, 2000); // toutes les 2 secondes
    
    // La subscription pour sauvegarder l'état du jeu
    gameState.subscribe(state => {
        updateGameState(state);
    });
}

// Initialiser les subscriptions côté navigateur
initializeBrowserSubscriptions();

// Fonction pour récupérer l'état depuis le backend
export async function fetchGameState(): Promise<void> {
    try {
        const response = await fetch(`${apiURL}/game-state`);
        if (!response.ok) throw new Error('Failed to fetch game state');
        const data = await response.json();
        const newState: GameState = {
            phase: data.phase || 'nuit',
            cycleCount: data.cycleCount || 0,
            gameStarted: data.gameStarted || false,
            showMayorElection: null,
            mayor: data.mayor || null,
            showSecondRoundAnnouncement: data.showSecondRoundAnnouncement || false,
            showVoteCountdown: data.showVoteCountdown || false,
            timer: data.timer || initialState.timer,
            rolesAssigned: data.rolesAssigned || false,
            enfantSauvageStates: data.enfantSauvageStates || {},
            chienLoupStates: data.chienLoupStates || {},
            eliminations: data.eliminations || [],
            users: data.users || [],
            allies: data.allies || [],
            memos: data.memos || [],
            loupVotes: data.loupVotes || {},
            loupVictim: data.loupVictim || null,
            dayVotes: data.dayVotes || {},
            isSecondRound: data.isSecondRound || false,
            secondRoundCandidates: data.secondRoundCandidates || [],
            subTimers: data.subTimers || [],
            selectedPlayers: data.selectedPlayers || [],
        };
        gameState.set(newState);
        updateTheme(newState.phase);
        
        // Appeler les callbacks avec les nouvelles données
        if (onTimerChange) onTimerChange(newState.timer);
        if (onRolesAssignedChange) onRolesAssignedChange(newState.rolesAssigned);
        if (onUsersChange) onUsersChange(newState.users as User[]);
        if (onSelectedPlayersChange) onSelectedPlayersChange(newState.selectedPlayers);
        if (onDayVotesChange) onDayVotesChange(newState.dayVotes);
        if (onSecondRoundChange) onSecondRoundChange(newState.isSecondRound, newState.secondRoundCandidates);
    } catch (error) {
        console.error('Error fetching game state:', error);
    }
}

// Fonction pour mettre à jour l'état sur le backend
export async function updateGameState(state: GameState): Promise<void> {
    try {
        const { showMayorElection, ...stateToSave } = state;
        const response = await fetch(`${apiURL}/game-state`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(stateToSave),
        });
        if (!response.ok) throw new Error('Failed to update game state');
    } catch (error) {
        console.error('Error updating game state:', error);
    }
}

// Fonction pour mettre à jour le thème
function updateTheme(phase: string | null) {
    if (typeof document === 'undefined' || phase === null) return;
    const html = document.documentElement;
    html.setAttribute('data-theme', phase);
}

// Fonction pour démarrer une nouvelle partie
export function startGame() {
    gameState.update(state => ({
        ...state,
        gameStarted: true,
        phase: 'nuit',
        cycleCount: 0,
        showMayorElection: null,
        mayor: null,
        timer: {
            timer: 3600,
            initialTimer: 3600,
            running: true,
            subTimers: {}
        },
        rolesAssigned: false,
        enfantSauvageStates: {},
        chienLoupStates: {},
        eliminations: [],
        loupVotes: {},
        loupVictim: null,
        dayVotes: {},
        isSecondRound: false,
        secondRoundCandidates: [],
        subTimers: [],
        selectedPlayers: []
    }));
    resetAll();
    timer.start();
}

// Fonction pour changer de phase
export const switchPhase = () => {
    gameState.update(state => {
        const currentPhase = state.phase;
        const newPhase = currentPhase === 'jour' ? 'nuit' : 'jour';
        let newCycle = state.cycleCount;

        // Si on passe de la nuit au jour, on incrémente le cycle
        if (currentPhase === 'nuit' && newPhase === 'jour') {
            newCycle++;
        }

        // Gestion des votes du jour
        if (currentPhase === 'jour' && newPhase === 'nuit') {
            const voteResult = getVoteResult();

            // Afficher le décompte des votes
            state.showVoteCountdown = true;

            // Attendre que le décompte soit terminé avant de continuer
            setTimeout(() => {
                gameState.update(s => {
                    // Jour 1 : Élection du maire
                    if (s.cycleCount === 1) {
                        if (voteResult.isTie && voteResult.tiedCandidates) {
                            // Si on est déjà au second tour et qu'il y a encore une égalité, on passe à la nuit #1
                            if (get(isSecondRound)) {
                                // Réinitialiser l'état du second tour
                                resetAll();
                                // On ne change pas le cycle car on veut rester à la nuit #1
                                updateTheme('nuit');
                                return {
                                    ...s,
                                    phase: 'nuit',
                                    showVoteCountdown: false
                                };
                            }
                            // Sinon, on démarre le second tour
                            startSecondRound(voteResult.tiedCandidates);
                            // Afficher l'animation du second tour
                            s.showSecondRoundAnnouncement = true;
                            return {
                                ...s,
                                phase: 'jour',
                                showVoteCountdown: false
                            };
                        }
                        // Nommer le maire
                        if (voteResult.winner) {
                            const player = getUserByLogin(voteResult.winner);
                            if (player) {
                                s.mayor = player.login;
                                s.showMayorElection = player.login;
                                setTimeout(() => {
                                    gameState.update(s => ({ ...s, showMayorElection: null }));
                                }, 5000);
                            }
                        }
                    } 
                    // Jours suivants : Élimination normale
                    else if (s.cycleCount > 1) {
                        if (voteResult.winner) {
                            eliminationStore.eliminate(voteResult.winner, 'vote', 'vote');
                        }
                    }

                    // Réinitialiser les votes après chaque phase de jour
                    resetDayVotes();
                    // Mettre à jour le thème avant de retourner le nouvel état
                    updateTheme('nuit');
                    return {
                        ...s,
                        phase: 'nuit',
                        showVoteCountdown: false
                    };
                });
            }, 5000); // Attendre 5 secondes pour le décompte

            return state;
        }

        // Réinitialiser l'état du second tour si on passe de nuit à jour
        if (currentPhase === 'nuit' && newPhase === 'jour') {
            resetAll();
        }

        updateTheme(newPhase);
        return {
            ...state,
            phase: newPhase,
            cycleCount: newCycle
        };
    });
    timer.reset();
    timer.start();
};

// Fonction pour réinitialiser la partie
export function resetGame() {
    gameState.set(initialState);
    updateTheme(null);
    resetAll();
    timer.reset();
    eliminationStore.reset();
    enfantSauvageStates.set({});
    chienLoupStates.set({});
    setUsers([]);
    allies.set([]);
    memos.set([]);
}

// Fonctions pour configurer les callbacks
export function setTimerCallback(callback: (timerState: TimerState) => void) {
    onTimerChange = callback;
}

export function setRolesAssignedCallback(callback: (assigned: boolean) => void) {
    onRolesAssignedChange = callback;
}

export function setUsersCallback(callback: (users: User[]) => void) {
    onUsersChange = callback;
}

export function setSelectedPlayersCallback(callback: (players: string[]) => void) {
    onSelectedPlayersChange = callback;
}

export function setDayVotesCallback(callback: (votes: Record<string, string>) => void) {
    onDayVotesChange = callback;
}

export function setSecondRoundCallback(callback: (isSecondRound: boolean, candidates: string[]) => void) {
    onSecondRoundChange = callback;
}

export function setCurrentUserCallback(callback: (login: string | null) => void) {
    onCurrentUserChange = callback;
}

